#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <time.h>

//Linked list node to store messages
typedef struct _message
{
	char *stringMessage;
	struct _message *next;
} message;

//Linked list node to store message boxes
typedef struct _messageBox
{
	char *name;
	message *head;
	struct _messageBox *next;
	pthread_mutex_t lock;
	int isOpen;
} messageBox;

//Thread arguments for each client 
typedef struct _threadArgs
{
	int clientSocket;
	struct sockaddr_in clientAddress;
} threadArgs;

pthread_mutex_t mainLock;
messageBox *head;

//Thread function to parse user client commands and act accordlying
void *socketThread(void *args)
{
	threadArgs *arguments = (threadArgs *)args;
	int newSocket = arguments->clientSocket;
	struct sockaddr_in clientAddress = arguments->clientAddress;

	//Gets IP address from the thread struct
	char *ipAddress = malloc(INET_ADDRSTRLEN);
	inet_ntop(AF_INET, &clientAddress.sin_addr, ipAddress, INET_ADDRSTRLEN);

	//These lines occur a lot. They set the time
	time_t timeStamp;
	struct tm currentTime;
	char stringTime[32];

	timeStamp = time(NULL);
	localtime_r(&timeStamp, &currentTime);
	strftime(stringTime, 32, "%a %b %e %T", &currentTime);

	printf("%s %s connected\n", stringTime, ipAddress);

	char buffer[1024];
	messageBox *currentBox;

	while (1)
	{
		memset(buffer, '\0', 1024);

		read(newSocket, buffer, sizeof(buffer));

		char *userInput = malloc(sizeof(char) * 5);
		memcpy(userInput, buffer, 5);

		//Executes when the client first connects to the server
		if (strncmp(userInput, "HELLO", 5) == 0)
		{
			timeStamp = time(NULL);
			localtime_r(&timeStamp, &currentTime);
			strftime(stringTime, 32, "%a %b %e %T", &currentTime);

			printf("%s %s HELLO\n", stringTime, ipAddress);

			char response[] = "HELLO DUMBv0 ready!";
			write(newSocket, response, sizeof(response));
		}
		//Executes when the client uses 'quit' and disconnects from the server
		else if (strncmp(userInput, "GDBYE", 5) == 0)
		{

			timeStamp = time(NULL);
			localtime_r(&timeStamp, &currentTime);
			strftime(stringTime, 32, "%a %b %e %T", &currentTime);

			printf("%s %s GDBYE\n", stringTime, ipAddress);

			close(newSocket);

			printf("%s %s disconnected\n", stringTime, ipAddress);

			pthread_exit(NULL);
		}
		//Executes when the user attempts to create a message box
		else if (strncmp(userInput, "CREAT", 5) == 0)
		{

			int nameSize = strlen(buffer + 6);

			char *boxName = (char *)malloc(nameSize);
			strcpy(boxName, buffer + 6);

			//This if statement occurs fairly often. It checks if the box name inputted by the user is viable
			if (nameSize < 5 || nameSize > 25 || isalpha(boxName[0]) == 0)
			{
				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				fprintf(stderr, "%s %s ER:WHAT?\n", stringTime, ipAddress);

				char response[] = "ER:WHAT?";
				write(newSocket, response, sizeof(response));

				continue;
			}

			//Checks if a message box has the same box name as the name the client is trying to create
			int doesExist = 0;
			messageBox *previous = NULL;
			messageBox *current = head;

			while (current != NULL)
			{
				if (strcmp(current->name, boxName) == 0)
				{
					doesExist = 1;
					break;
				}

				previous = current;
				current = current->next;
			}

			//Creates a new box if doesExist is equal to 0; If not, an error is output
			if (doesExist == 0)
			{
				messageBox *newBox = (messageBox *)malloc(sizeof(messageBox));
				newBox->name = boxName;
				newBox->isOpen = 0;
				newBox->head = NULL;
				newBox->next = NULL;

				pthread_mutex_lock(&mainLock);

				if (previous == NULL)
					head = newBox;
				else
					previous->next = newBox;

				pthread_mutex_unlock(&mainLock);

				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				printf("%s %s CREAT\n", stringTime, ipAddress);

				char response[] = "OK!";
				write(newSocket, response, sizeof(response));
			}
			else
			{
				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				fprintf(stderr, "%s %s ER:EXIST\n", stringTime, ipAddress);

				char response[] = "ER:EXIST";
				write(newSocket, response, sizeof(response));
			}
		}
		//Executes when the user attempts to open a box
		else if (strncmp(userInput, "OPNBX", 5) == 0)
		{

			int nameSize = strlen(buffer + 6);

			char *boxName = (char *)malloc(nameSize);
			strcpy(boxName, buffer + 6);

			if (nameSize < 5 || nameSize > 25 || isalpha(boxName[0]) == 0)
			{
				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				fprintf(stderr, "%s %s ER:WHAT?\n", stringTime, ipAddress);

				char response[] = "ER:WHAT?";
				write(newSocket, response, sizeof(response));

				continue;
			}

			//Checks if there is a message box with a name the same as the name the user is trying to open
			messageBox *current = head;
			while (current != NULL)
			{
				if (strcmp(current->name, boxName) == 0)
					break;

				current = current->next;
			}

			if (current != NULL)
			{
				if (current->isOpen == 0)
				{
					pthread_mutex_lock(&(current -> lock));

					currentBox = current;
					currentBox->isOpen = 1;

					timeStamp = time(NULL);
					localtime_r(&timeStamp, &currentTime);
					strftime(stringTime, 32, "%a %b %e %T", &currentTime);

					printf("%s %s OPNBX\n", stringTime, ipAddress);

					char response[] = "OK!";
					write(newSocket, response, sizeof(response));
				}
				//The message box is already opened
				else
				{
					timeStamp = time(NULL);
					localtime_r(&timeStamp, &currentTime);
					strftime(stringTime, 32, "%a %b %e %T", &currentTime);

					fprintf(stderr, "%s %s ER:OPEND\n", stringTime, ipAddress);

					char response[] = "ER:OPEND";
					write(newSocket, response, sizeof(response));
				}
			}
			//The message box does not exist
			else
			{
				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				fprintf(stderr, "%s %s ER:NEXST\n", stringTime, ipAddress);

				char response[] = "ER:NEXST";
				write(newSocket, response, sizeof(response));
			}
		}
		//Executes when the user is attempting to get the next message in the message box
		else if (strncmp(userInput, "NXTMG", 5) == 0)
		{

			if (currentBox != NULL)
			{
				if (currentBox->head != NULL)
				{
					char *firstMessage = currentBox->head->stringMessage;
					int size = strlen(firstMessage);

					timeStamp = time(NULL);
					localtime_r(&timeStamp, &currentTime);
					strftime(stringTime, 32, "%a %b %e %T", &currentTime);

					printf("%s %s NXTMG\n", stringTime, ipAddress);

					char *response = (char*)malloc(3 + strlen(firstMessage));
					sprintf(response, "OK!%d!%s", size, firstMessage);

					write(newSocket, response, strlen(response));

					message *temp = currentBox->head;
					currentBox->head = currentBox->head->next;
					free(temp);
				}
				//The message box is already empty
				else
				{
					timeStamp = time(NULL);
					localtime_r(&timeStamp, &currentTime);
					strftime(stringTime, 32, "%a %b %e %T", &currentTime);

					fprintf(stderr, "%s %s ER:EMPTY\n", stringTime, ipAddress);

					char response[] = "ER:EMPTY";
					write(newSocket, response, sizeof(response));
				}
			}
			//There is no message box currently open
			else
			{
				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				fprintf(stderr, "%s %s ER:NOOPN\n", stringTime, ipAddress);

				char response[] = "ER:NOOPN";
				write(newSocket, response, sizeof(response));
			}
		}
		//Executes when the user attempts to put a message inside a message box
		else if (strncmp(userInput, "PUTMG", 5) == 0)
		{
			char* stringMessageSize = strtok(buffer + 6, "!");
			int newMessageSize = atoi(stringMessageSize);

			char *newStringMessage = (char*)malloc(newMessageSize);  
			strcpy(newStringMessage, buffer + 7 + strlen(stringMessageSize));

			if (currentBox != NULL)
			{
				message *previous = NULL;
				message *current = currentBox->head;

				while (current != NULL)
				{
					previous = current;
					current = current->next;
				}
				message *newMessage = (message *)malloc(sizeof(message));
				newMessage->stringMessage = newStringMessage;
				newMessage->next = NULL;

				if (previous == NULL)
				{
					currentBox->head = newMessage;
				}
				else
				{
					previous->next = newMessage;
				}

				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				printf("%s %s PUTMG\n", stringTime, ipAddress);

				char *response = (char*)malloc(3 + strlen(stringMessageSize));
				sprintf(response, "OK!%d", newMessageSize);

				write(newSocket, response, strlen(response));
			}
			//There is no message box currently open
			else
			{
				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				fprintf(stderr, "%s %s ER:NOOPN\n", stringTime, ipAddress);

				char response[] = "ER:NOOPN";
				write(newSocket, response, sizeof(response));
			}
		}
		//Executes when the user is attempting to delete a message box
		else if (strncmp(userInput, "DELBX", 5) == 0)
		{

			int nameSize = strlen(buffer + 6);

			char *boxName = (char *)malloc(nameSize);
			strcpy(boxName, buffer + 6);

			if (nameSize < 5 || nameSize > 25 || isalpha(boxName[0]) == 0)
			{
				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				fprintf(stderr, "%s %s ER:WHAT?\n", stringTime, ipAddress);

				char *response = "ER:WHAT?";
				write(newSocket, response, sizeof(response));

				continue;
			}

			messageBox *previous = NULL;
			messageBox *current = head;

			while (current != NULL)
			{
				if (strcmp(current->name, boxName) == 0)
					break;

				previous = current;
				current = current->next;
			}

			if (current != NULL)
			{
				if (current->isOpen == 0)
				{
					if (current->head == NULL)
					{
						pthread_mutex_lock(&mainLock);

						if (previous == NULL)
						{
							head = head -> next;
						}
						else
						{
							previous->next = current->next;
						}

						pthread_mutex_unlock(&mainLock);
						free(current);

						timeStamp = time(NULL);
						localtime_r(&timeStamp, &currentTime);
						strftime(stringTime, 32, "%a %b %e %T", &currentTime);

						printf("%s %s DELBX\n", stringTime, ipAddress);

						char response[] = "OK!";
						write(newSocket, response, sizeof(response));
					}
					//There are still messages inside the message box
					else
					{
						printf("test %s\n", current->head->stringMessage);
						timeStamp = time(NULL);
						localtime_r(&timeStamp, &currentTime);
						strftime(stringTime, 32, "%a %b %e %T", &currentTime);

						fprintf(stderr, "%s %s ER:NOTMT\n", stringTime, ipAddress);

						char response[] = "ER:NOTMT";
						write(newSocket, response, sizeof(response));
					}
				}
				//The message box is currently open
				else
				{
					timeStamp = time(NULL);
					localtime_r(&timeStamp, &currentTime);
					strftime(stringTime, 32, "%a %b %e %T", &currentTime);

					fprintf(stderr, "%s %s ER:OPEND\n", stringTime, ipAddress);

					char response[] = "ER:OPEND";
					write(newSocket, response, sizeof(response));
				}
			}
			//The message box does not exist
			else
			{
				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				fprintf(stderr, "%s %s ER:NEXST\n", stringTime, ipAddress);

				char response[] = "ER:NEXST";
				write(newSocket, response, sizeof(response));
			}
		}
		//Executes when the user attemps to close a message box
		else if (strncmp(userInput, "CLSBX", 5) == 0)
		{

			int nameSize = strlen(buffer + 6);

			char *boxName = (char *)malloc(nameSize);
			strcpy(boxName, buffer + 6);

			if (nameSize < 5 || nameSize > 25 || isalpha(boxName[0]) == 0)
			{
				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				fprintf(stderr, "%s %s ER:WHAT?\n", stringTime, ipAddress);

				char response[] = "ER:WHAT?";
				write(newSocket, response, sizeof(response));

				continue;
			}

			//There is no message box open, or the name of the corresponding message box is different
			if (currentBox == NULL || strcmp(currentBox->name, boxName) != 0)
			{
				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				fprintf(stderr, "%s %s ER:NOOPN\n", stringTime, ipAddress);

				char response[] = "ER:NOOPN";
				write(newSocket, response, sizeof(response));
			}
			else
			{
				pthread_mutex_unlock(&(currentBox->lock));
				currentBox->isOpen = 0;
				currentBox = NULL;

				timeStamp = time(NULL);
				localtime_r(&timeStamp, &currentTime);
				strftime(stringTime, 32, "%a %b %e %T", &currentTime);

				printf("%s %s CLSBX\n", stringTime, ipAddress);

				char response[] = "OK!";
				write(newSocket, response, sizeof(response));
			}
		}
		//Executes when the user inputted an incorrect command
		else
		{

			timeStamp = time(NULL);
			localtime_r(&timeStamp, &currentTime);
			strftime(stringTime, 32, "%a %b %e %T", &currentTime);

			fprintf(stderr, "%s %s ER:WHAT?\n", stringTime, ipAddress);

			char response[] = "ER:WHAT?";
			write(newSocket, response, sizeof(response));
		}
	}
}

int main(int argc, char **argv)
{
	if (argc != 2)
	{
		perror("Error: Illegal number of arguments\n");
		return 0;
	}

	//Socket creation
	int serverSocket = socket(AF_INET, SOCK_STREAM, 0);

	struct sockaddr_in serverAddress;

	//Configure settings of the server address struct
	serverAddress.sin_family = AF_INET;

	//Set port number
	serverAddress.sin_port = htons(atoi(argv[1]));

	//Set IP address to localhost
	serverAddress.sin_addr.s_addr = inet_addr("127.0.0.1");

	//Binding newly created socket to given IP and verification
	if (bind(serverSocket, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) < 0)
	{
		perror("Error: Binding failed\n");
		return 0;
	}

	//Listen on the socket, with 20 max connection requests queued
	if (listen(serverSocket, 20))
	{
		perror("Error: Listen failed\n");
		return 0;
	}

	pthread_t differentClients[20];
	int clientNumber = 0;

	//Recieve connection
	struct sockaddr_in clientAddress;
	socklen_t clientAddressSize = sizeof(clientAddress);
	int newSocket;

	while (1)
	{
		//Accept call creates a new socket for the incoming connection
		newSocket = accept(serverSocket, (struct sockaddr *)&clientAddress, &clientAddressSize);
		if (newSocket < 0)
		{
			perror("Error: Accept failed\n");
			break;
		}

		threadArgs *clientArguments = (threadArgs *)malloc(sizeof(threadArgs));
		clientArguments->clientSocket = newSocket;
		clientArguments->clientAddress = clientAddress;

		//For each client request creates a thread and assign the client request to it to process
		//So the main thread can entertain next request
		pthread_create(&differentClients[clientNumber++], NULL, socketThread, clientArguments);

		if (clientNumber == 20)
		{
			perror("Error: client max capacity reached\n");
			break;
		}
	}

	return 0;
}