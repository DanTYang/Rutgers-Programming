#include <stdlib.h>
#include <stdio.h>

#include <netdb.h>
#include <string.h>
#include <sys/socket.h>

#define MAX_ARG_SZ 256
#define MAX_CMD_SZ 256

//Converts user inputs as an equivalent command
int parseMsg(char *a)
{
    char hello[] = "hello", help[] = "help", quit[] = "quit", create[] = "create", delete[] = "delete", open[] = "open", close[] = "close", next[] = "next", put[] = "put";
    if (strcmp(a, hello) == 0)
    {
        return 0;
    }
    else if (strcmp(a, quit) == 0)
    {
        return 1;
    }
    else if (strcmp(a, create) == 0)
    {
        return 2;
    }
    else if (strcmp(a, delete) == 0)
    {
        return 3;
    }
    else if (strcmp(a, open) == 0)
    {
        return 4;
    }
    else if (strcmp(a, close) == 0)
    {
        return 5;
    }
    else if (strcmp(a, next) == 0)
    {
        return 6;
    }
    else if (strcmp(a, put) == 0)
    {
        return 7;
    }
    else if (strcmp(a, help) == 0)
    {
        return 8;
    }
    return -1;
}

//Based on the given command, acts accordingly when communicating with the server
char *cmdSet(int a, int clientSocket)
{
    char *arg = malloc(MAX_ARG_SZ);
    //Executes when the client connects to the server
    if (a == 0)
    {
        char HELLO[] = "HELLO";
        write(clientSocket, HELLO, 5);
        char *buffer = malloc(1024);
        read(clientSocket, buffer, 1024);
        if (strcmp(buffer, "HELLO DUMBv0 ready!") != 0)
        {
            printf("Error: Cound not connect to the server!\n");
            return "GDBYE";
        }
        printf("%s\n", buffer);
        return buffer;
    }
    //Executes when the client disconnects from the server
    else if (a == 1)
    {
        char GDBYE[] = "GDBYE";
        write(clientSocket, GDBYE, 5);
        char *buffer = malloc(1024);

        printf("Quiting server...\n");
        return "GDBYE";
    }
    //Executes when the client trys to create a new message box
    else if (a == 2)
    {
        printf("Okay, create which message box?\n");
        printf("CREAT:> ");
        fgets(arg, MAX_ARG_SZ, stdin);
        /* Remove trailing newline, if there. */
        if ((strlen(arg) > 0) && (arg[strlen(arg) - 1] == '\n'))
        {
            arg[strlen(arg) - 1] = '\0';
        }
        if (arg != NULL)
        {
            char CREAT[] = "CREAT";
            strcat(CREAT, " ");
            strcat(CREAT, arg);
            write(clientSocket, CREAT, sizeof(CREAT) + strlen(arg) + 1);
            char *buffer = malloc(1024);
            read(clientSocket, buffer, 1024);
            if(strcmp(buffer, "ER:EXIST")==0)
            {
                printf("Error Found: Message Box already exists\n");
            }
            else if(strcmp(buffer, "ER:WHAT?")==0)
            {
                printf("Error Found: Command could not be parsed\n");
            }
            else
            {
                printf("Success! Message box created\n");
            }
            return buffer;
        }
    }
    //Executes when the client trys to delete a message box
    else if (a == 3)
    {
        printf("Okay, delete which message box?\n");
        printf("DELBX:> ");
        fgets(arg, MAX_ARG_SZ, stdin);
        /* Remove trailing newline, if there. */
        if ((strlen(arg) > 0) && (arg[strlen(arg) - 1] == '\n'))
        {
            arg[strlen(arg) - 1] = '\0';
        }
        if (arg != NULL)
        {
            char DELBX[] = "DELBX";
            strcat(DELBX, " ");
            strcat(DELBX, arg);
            write(clientSocket, DELBX, sizeof(DELBX) + strlen(arg) + 1);
            char *buffer = malloc(1024);
            read(clientSocket, buffer, 1024);
            if(strcmp(buffer, "ER:WHAT?")==0)
            {
                printf("Error Found: Could not parse message\n");
            }
            else if(strcmp(buffer, "ER:NOTMT")==0)
            {
                printf("Error Found: Message box still has messages\n");
            }
            else if(strcmp(buffer, "ER:OPEND")==0)
            {
                printf("Error Found: Message box is still opened\n");
            }
            else if(strcmp(buffer, "ER:NEXST")==0)
            {
                printf("Error Found: Message box '%s', does not exist\n", arg);
            }
            else
            {
                printf("Success! Deleted message box '%s'\n", arg);
            }
            return buffer;
        }
    }
    //Executes when the client trys to open a message box
    else if (a == 4)
    {
        printf("Okay, open which message box?\n");
        printf("OPNBX:> ");
        fgets(arg, MAX_ARG_SZ, stdin);
        /* Remove trailing newline, if there. */
        if ((strlen(arg) > 0) && (arg[strlen(arg) - 1] == '\n'))
        {
            arg[strlen(arg) - 1] = '\0';
        }
        if (arg != NULL)
        {
            char OPNBX[] = "OPNBX";
            strcat(OPNBX, " ");
            strcat(OPNBX, arg);
            write(clientSocket, OPNBX, sizeof(OPNBX) + strlen(arg) + 1);
            char *buffer = malloc(1024);
            read(clientSocket, buffer, 1024);
            if(strcmp(buffer, "ER:OPEND")==0)
            {
                printf("Error Found: Already opened\n");
            }
            else if(strcmp(buffer, "ER:NEXST")==0)
            {
                printf("Error Found: Message box does not exist\n");
            }
            else if(strcmp(buffer, "ER:WHAT?")==0)
            {
                printf("Error Found: Could not parse command\n");
            }
            else
            {
                printf("Success! Opened Message Box '%s'\n", arg);
            }
            return buffer;
        }
    }

    else if (a == 5)
    {
        printf("Okay, close which message box?\n");
        printf("CLSBX:> ");
        fgets(arg, MAX_ARG_SZ, stdin);
        /* Remove trailing newline, if there. */
        if ((strlen(arg) > 0) && (arg[strlen(arg) - 1] == '\n'))
        {
            arg[strlen(arg) - 1] = '\0';
        }
        if (arg != NULL)
        {
            char CLSBX[] = "CLSBX";
            strcat(CLSBX, " ");
            strcat(CLSBX, arg);
            write(clientSocket, CLSBX, sizeof(CLSBX) + strlen(arg) + 1);
            char *buffer = malloc(1024);
            read(clientSocket, buffer, 1024);
            if(strcmp(buffer, "ER:WHAT?")==0)
            {
                printf("Error Found: Could not parse message\n");
            }
            else if(strcmp(buffer, "ER:NOOPN")==0)
            {
                printf("Error Found: Message Box is not open\n");
            }
            else
            {
                printf("Success! Closed Message Box '%s'\n", arg);
            }
            return buffer;
        }
    }
    //Executes when the client trys to get the next message from a message box
    else if (a == 6)
    {
        char NXTMG[] = "NXTMG";
        write(clientSocket, NXTMG, sizeof(NXTMG) + strlen(arg) + 1);
        char *buffer = malloc(1024);
        read(clientSocket, buffer, 1024);
        if(strcmp(buffer, "ER:EMPTY")==0)
        {
             printf("Error Found: No messages in the message box\n");
        }
        else
        {
             char* stringMessageSize = strtok(buffer + 3, "!");
			 int newMessageSize = atoi(stringMessageSize);

			 char *newStringMessage = (char*)malloc(newMessageSize);  
			 strcpy(newStringMessage, buffer + 4 + strlen(stringMessageSize));
             printf("Success! The next message: %s\n", newStringMessage);
        }
        return buffer;
    }
    //Executes when the client trys to put a messgae in a message box
    else if (a == 7)
    {
        char *msg = malloc(MAX_ARG_SZ);
        printf("Enter the length of the message\n");
        printf("PUTMG:> ");
        fgets(arg, MAX_ARG_SZ, stdin);
        /* Remove trailing newline, if there. */
        if ((strlen(arg) > 0) && (arg[strlen(arg) - 1] == '\n'))
        {
            arg[strlen(arg) - 1] = '\0';
        }
        int x = -1;
        while(x != atoi(arg))
        {
            printf("Enter the message\n");
            printf("PUTMG:> ");
            fgets(msg, MAX_ARG_SZ, stdin);
            /* Remove trailing newline, if there. */
            if ((strlen(msg) > 0) && (msg[strlen(msg) - 1] == '\n'))
            {
                msg[strlen(msg) - 1] = '\0';
            }
            if(strlen(msg) != atoi(arg))
            {
                printf("Error Found: Message not size of allocated size, please try again\n");
            }
            x = strlen(msg);
        }
        if (arg != NULL && msg != NULL)
        {
            char PUTMG[] = "PUTMG";
            strcat(PUTMG, "!");
            strcat(PUTMG, arg);
            strcat(PUTMG, "!");
            strcat(PUTMG, msg);
            write(clientSocket, PUTMG, sizeof(PUTMG) + strlen(msg) + strlen(arg) + 2);
            char *buffer = malloc(1024);
            read(clientSocket, buffer, 1024);
            if(strcmp(buffer, "ER:NOOPN") == 0)
            {
                printf("Error Found: No message box open!\n");
            }
            else
            {
                printf("Success! Message of size '%d' has been put in the message box\n", atoi(buffer+3));
            }
            return buffer;
        }
    }
    //Executes when the user enters help and wants a list of all the available commandds
    else if(a == 8)
    {
        printf("Commands are:\n");
        printf("quit\t\t(which causes: GDBYE)\n");
		printf("create\t\t(which causes: CREAT)\n");
		printf("delete\t\t(which causes: DELBX)\n");		
		printf("open\t\t(which causes: OPNBX)\n");
		printf("close\t\t(which causes: CLSBX)\n");
		printf("next\t\t(which causes: NXTMG)\n");
		printf("put\t\t(which causes: PUTMG)\n");
        return "10";
    }
    //Executes when the user enters an invalid command
    else
    {
        char ehhh[] = "asdf";
        write(clientSocket, ehhh, sizeof(ehhh));
        char *buffer = malloc(1024);
        read(clientSocket, buffer, 1024);
        printf("That is not a command, for a command list enter \'help\'\n");
        return buffer;
    }
}

int main(int argc, char **argv)
{
    if (argc != 3)
    {
        perror("Error: Illegal number of arguments\n");
        return 0;
    }

    //Connects the client socket to the server
    int clientSocket = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in serverAddress;

    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = inet_addr(argv[1]);
    serverAddress.sin_port = htons(atoi(argv[2]));

    connect(clientSocket, (struct sockaddr *)&serverAddress, sizeof(serverAddress));

    char *cmd = malloc(MAX_CMD_SZ);
    char *helper = malloc(MAX_CMD_SZ);
    if (cmd == NULL)
    {
        printf("Error: No memory\n");
        return 1;
    }
    cmdSet(0, clientSocket);
    while (cmd != "GDBYE")
    {
        cmd = helper;
        printf("> ");
        fgets(cmd, MAX_CMD_SZ, stdin);
        /* Remove trailing newline, if there. */
        if ((strlen(cmd) > 0) && (cmd[strlen(cmd) - 1] == '\n'))
        {
            cmd[strlen(cmd) - 1] = '\0';
        }
        int temp = parseMsg(cmd);
        cmd = cmdSet(temp, clientSocket);
    }
    return 0;
}
